 <p class="wpo_section duration">
  <?php
      $_duration = array('id'=>'duration', 'title'=>esc_html__('Duration Time', 'training'), 'des'=>'' );
      $mb->addTextElement( $_duration );
  ?>
</p>
