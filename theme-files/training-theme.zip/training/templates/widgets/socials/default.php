
<div class="bo-social-icons bo-sicolor text-center">
    <?php foreach( $socials as $key=>$social):
            if( isset($social['status']) && !empty($social['page_url']) ): ?>
                <a href="<?php echo esc_url($social['page_url']);?>" class="bo-social-<?php echo esc_attr($key); ?> radius-x">
                    <i class="fa fa-<?php echo esc_attr($key); ?>">&nbsp;</i>
                </a>
    <?php
            endif;
        endforeach;
    ?>
</div>