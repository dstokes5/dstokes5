<ul class="list-inline userlinks">
	<li><a href=""><?php esc_html_e( 'Login', 'training'); ?></a></li>
	<li><a href=""><?php esc_html_e( 'Register', 'training'); ?></a></li>
</ul>	