<div class="testimonials-body">
    <p class="testimonials-description"><?php the_content() ?></p>                            
    <h5 class="testimonials-name">
         <?php the_title(); ?>
    </h5>  
    <p class="text-muted testimonials-position"><?php the_excerpt(); ?></p>  
</div>