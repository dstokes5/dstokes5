<?php
function training_fnc_import_remote_demos() { 
   return array(
      'training' => array( 'name' => 'training',  'source'=> 'http://wpsampledemo.com/training/training.zip' ),
   );
}

add_filter( 'pbrthemer_import_remote_demos', 'training_fnc_import_remote_demos' );



function training_fnc_import_theme() {
   return 'training';
}
add_filter( 'pbrthemer_import_theme', 'training_fnc_import_theme' );

function training_fnc_import_demos() {
   $folderes = glob( WPO_THEME_DIR.'/inc/import/*', GLOB_ONLYDIR ); 

   $output = array(); 

   foreach( $folderes as $folder ){
      $output[basename( $folder )] = basename( $folder );
   }
   
   return $output;
}
add_filter( 'pbrthemer_import_demos', 'training_fnc_import_demos' );

function training_fnc_import_types() {
   return array(
         'all' => 'All',
         'content' => 'Content',
         'widgets' => 'Widgets',
         'page_options' => 'Theme + Page Options',
         'menus' => 'Menus',
         'rev_slider' => 'Revolution Slider',
         'vc_templates' => 'VC Templates'
      );
}
add_filter( 'pbrthemer_import_types', 'training_fnc_import_types' );



/**
 * Matching and resizing images with url.
 *
 *  $ouput = array(
 *        'allowed' => 1, // allow resize images via using GD Lib php to generate image
 *        'height'  => 900,
 *        'width'   => 800,
 *        'file_name' => 'blog_demo.jpg'
 *   ); 
 */
function training_import_attachment_image_size( $url ){  

   $name = basename( $url );   
 
   $ouput = array(
         'allowed' => 0
   );     
   
   if( preg_match("#product#", $name) ) {
      $ouput = array(
         'allowed' => 1,
         'height'  => 1000,
         'width'   => 1000,
         'file_name' => 'product_demo.jpg'
      ); 
   }
   elseif( preg_match("#blog#", $name) || preg_match("#news-#", $name) || preg_match("#post-#", $name) ){
      $ouput = array(
         'allowed' => 1,
         'height'  => 800,
         'width'   => 1170,
         'file_name' => 'blog_demo.jpg'
      ); 
   }

   elseif( preg_match("#courses-#", $name) || preg_match("#course-#", $name) ){
      $ouput = array(
         'allowed' => 1,
         'height'  => 600,
         'width'   => 920,
         'file_name' => 'courses_demo.png'
      ); 
   }

  elseif( preg_match("#gallery#", $name) ){
      $ouput = array(
         'allowed' => 1,
         'height'  => 1170,
         'width'   => 1170,
         'file_name' => 'gallery_demo.png'
      ); 
   }

   elseif( preg_match("#portfolio#", $name) ){
      $ouput = array(
         'allowed' => 1,
         'height'  => 800,
         'width'   => 1170,
         'file_name' => 'portfolio_demo.png'
      ); 
   }
   elseif( preg_match("#team#", $name) ){
      $ouput = array(
         'allowed' => 1,
         'height'  => 680,
         'width'   => 570,
         'file_name' => 'team_demo.jpg'
      ); 
   }
   elseif( preg_match("#testimonial#", $name) ){
      $ouput = array(
         'allowed' => 1,
         'height'  => 900,
         'width'   => 900,
         'file_name' => 'testimonial_demo.jpg'
      ); 
   }

   return $ouput;
}

add_filter( 'pbrthemer_import_attachment_image_size', 'training_import_attachment_image_size' , 1 , 999 );
