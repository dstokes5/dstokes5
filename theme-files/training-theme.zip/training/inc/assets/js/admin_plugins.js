var WPO_Admin = window.WPO_Admin || {};

!function ($) {
	"use strict";
	$.extend(WPO_Admin, {
		init: function(){
			WPO_Admin.PageOption();
		},
		//define
		// params
	    params_Embed : function (input_id,parent_id){
	    	var input = jQuery(input_id);
	    	if(input.length>0){
		    	var oembed_url = input.val();
		    	if(oembed_url!="" && oembed_url.length>6){
		    		jQuery(parent_id+' .spinner').css('display','block');
		    		WPO_Admin.param_start_ajax_embed(oembed_url,parent_id);
		    	}
		        input.on('keyup', function (event) {
					WPO_Admin.param_ajax_Embed(jQuery(this), event,parent_id,input_id);
				});
			}
	    },

	    param_ajax_Embed : function (obj, e,parent_id,input_id) {
			// get typed value
			var oembed_url = obj.val();
			// only proceed if the field contains more than 6 characters
			if (oembed_url.length < 6)
				return;
			// only proceed if the user has pasted, pressed a number, letter, or whitelisted characters
			if (e === 'paste' || e.which <= 90 && e.which >= 48 || e.which >= 96 && e.which <= 111 || e.which == 8 || e.which == 9 || e.which == 187 || e.which == 190) {
				jQuery(parent_id+' .spinner').css('display','block');
				// clear out previous results
				jQuery(parent_id+' .result').html('');
				// and run our ajax function
				setTimeout(function () {
					// if they haven't typed in 500 ms
					if (jQuery(input_id+':focus').val() == oembed_url) {
						WPO_Admin.param_start_ajax_embed(oembed_url,parent_id);
					}
				}, 500);
			}
		},
		param_start_ajax_embed : function (oembed_url,parent_id){
		    jQuery.ajax({
				type : 'post',
				dataType : 'json',
				url : window.ajaxurl,
				data : {
					'action': 'wpo_post_embed',
					'oembed_url': oembed_url
				},
				success: function (response) {
					jQuery(parent_id+' .spinner').css('display','none');
					// if we have a response id
					if(response.check){
	                    jQuery(parent_id+' .wpo_embed_view .result').addClass('active').append(response.video);
	                    jQuery(parent_id+' .wpo_embed_view .result').append('<a class="remove-embed"></a>');
	                    jQuery(parent_id+' .result a.remove-embed').click(function(){
	                    	jQuery(parent_id).find('input').val("");
	                    	jQuery(parent_id+' .result').html("");
	                    	jQuery(parent_id+' .result').removeClass('active');
	                    });
	                }else{
	                	jQuery(parent_id+' .wpo_embed_view .result').append(response.video);
	                }
				}
			});
		},
		// Page Option Config
		PageOption : function(){
	    	 $( ".wpo-metabox .page-layout" ).each( function(){
	    	 	var $this = $this; 
				var $select = $('select',this);
				var $val = $select.val();
				var $img = $('img.layout', this );
				if( $val ){
					$img.each( function(){
						if( $val == $(this).data('value') ){
							$(this).addClass( 'selected');
						}
					} );
				}
				$("select", this).hide();
			
				$img.each( function(){
					var $i = $(this);
					$i.click( function() {  
						$img.removeClass('selected');
						$i.addClass('selected');
						$select.val( $i.data('value') );
						$select.change();
						$(".target-page-layout", $this).hide('slow');
						$(".for-"+ $i.data('value')).show('slow');

					} );
				} );
			} );
	    }
	});

	jQuery(document).ready(function(){
		WPO_Admin.init();
	});

}(jQuery);


jQuery(document).ready(function($) {

	function hide_statuses() {
		$('#wpo_formataudio_metabox, #wpo_formataside_metabox, #wpo_formatchat_metabox, #wpo_formatgallery_metabox, #wpo_formatimage_metabox, #wpo_formatvideo_metabox, #wpo_formatlink_metabox, #wpo_formatquote_metabox,#wpo_formatstatus_metabox,#wpo_formatvideo_metabox').hide();
	}


	if($("#post-formats-select").length) {
	
		hide_statuses();
		// Supported post formats
		var post_formats = ['audio','aside','chat','gallery','image','link','quote','status','video'];

		// Get selected post format
		var selected_post_format = $("input[name='post_format']:checked").val();

		// Show post format meta box
		if(jQuery.inArray(selected_post_format,post_formats) != '-1') {
			$('#format-'+selected_post_format).show();
		}

		$("input[name='post_format']:radio").change(function() { 	 
			// Hide post format sections
			hide_statuses();
			// Shoe selected section
			if(jQuery.inArray($(this).val(),post_formats) != '-1') {
				$('#wpo_format'+$(this).val()+"_metabox").show();
			}
		});
	}

});